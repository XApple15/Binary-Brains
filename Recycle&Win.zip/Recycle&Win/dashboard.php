<?php
session_start();
 
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}

?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Contul meu</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body{ font: 14px sans-serif; text-align: center; }
    </style>
</head>
<body>
    <h1 class="my-5">Hi, <b><?php echo htmlspecialchars($_SESSION["username"]);?></b>.s</h1>
    <h2> You have  <?php  echo $_SESSION["points"];?> points</h2>
    <p>
        <a href="reset-password.php" class="btn btn-warning">Reset Your Password</a>
        <a href="logout.php" class="btn btn-danger ml-3">Sign Out of Your Account</a>
    </p>


<?Php
require "config.php";
$query="select id, name, price,image FROM vouchers";


if ($result_set = $link->query($query)) {
while($row = $result_set->fetch_array(MYSQLI_ASSOC)){
    ?>
    <section class="white-section" id="pricing">
  <div class="row">
    <div class="pricing-column col-lg-3 col-md-6">
      <div class="card">
        <div class="card-header">
          <h3> <?php echo $row['id'],$row['name']; ?> </h3>
        </div>
        <div class="card-body">
         <img src = "/images/$row['image']" alt="v1" width="180" height="210">
         <p><?php echo $row['price']; ?></p>
          <button class="btn btn-lg btn-block btn-outline-dark" type="button">Ia cuponul</button>
        </div>
      </div>
    </div>
<?php
}
 $result_set->close();
}
?>
</body>
</html>





